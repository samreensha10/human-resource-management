<?php
$FirstName=$_POST['FirstName'];
$LastName=$_POST['LastName'];
$EmailId=$_POST['EmailId'];
$EnterPassword=$_POST['EnterPassword'];
$ConfirmPassword=$_POST['ConfirmPassword'];
$servername="localhost";
$username="root";
$password="";
$dbname="hrms";
//Create connection
$conn=new mysqli($servername,$username,$password,$dbname);
// Check connection
if($conn->connect_error){
    die("connection failed:" . $conn->connect_error);


}
$sql="INSERT INTO register (FirstName,LastName,EmailId,EnterPassword,ConfirmPassword)
VALUES ('$FirstName','$LastName','$EmailId','$EnterPassword','$ConfirmPassword')";
if($conn->query($sql)==TRUE){
    echo"new record created sucessfully";
}
else{
   echo "error".$sql. "<br>" .$conn->error;


}
$conn->close();

?>