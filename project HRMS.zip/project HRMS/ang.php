<?php
$Empid=$_POST['Empid'];
$Empname=$_POST['Empname'];
$Lastdate=$_POST['Lastdate'];
$Startdate=$_POST['Startdate'];
$Reason=$_POST['Reason'];
$Totaldays=$_POST['Totaldays'];
$Status=$_POST['Status'];
$servername="localhost";
$username="root";
$password="";
$dbname="hrms";
//Create connection
$conn=new mysqli($servername,$username,$password,$dbname);
// Check connection
if($conn->connect_error){
    die("connection failed:" . $conn->connect_error);
}
$sql="INSERT INTO leavemanagement(Empid,Empname,Lastdate,Startdate,Reason,Totaldays,Status)
VALUES ('$Empid','$Empname','$Lastdate','$Startdate','$Reason','$Totaldays','$Status')";
if($conn->query($sql)==TRUE){
    echo"new record created sucessfully";
}
else{
   echo "error".$sql. "<br>" .$conn->error;
}
$conn->close();
?>