<?php
$Homephone=$_POST['Homephone'];
$WorkPlace=$_POST['WorkPlace'];
$Email=$_POST['Email'];
$MobilePhone=$_POST['MobilePhone'];
$Gender=$_POST['Gender'];
$Status=$_POST['Status'];
$Depertment=$_POST['Depertment'];
$BirthDate=$_POST['BirthDate'];
$servername="localhost";
$username="root";
$password="";
$dbname="hrms";
//Create connection
$conn=new mysqli($servername,$username,$password,$dbname);
// Check connection
if($conn->connect_error){
    die("connection failed:" . $conn->connect_error);
}
$sql="INSERT INTO employ(Homephone,WorkPlace,Email,MobilePhone,Gender,Status,Depertment,BirthDate)
VALUES ('$Homephone','$WorkPlace','$Email','$MobilePhone','$Gender','$Status','$Depertment','$BirthDate')";
if($conn->query($sql)==TRUE){
    echo"new record created sucessfully";
}
else{
   echo "error".$sql. "<br>" .$conn->error;
}
$conn->close();
?>