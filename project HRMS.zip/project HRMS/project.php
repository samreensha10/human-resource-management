<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="project.css">
    <title>Document</title>
  

</head>
<body>
    <div class="full-page">
        <div class="navbar">
            <div>
                <a href='website.html'>Human Resource Management System </a>
            </div>
            <nav>
                <ul id='MenuItems'>
                    
                    <li><button class='loginbtn' onclick="document.getElementById('login-form').style.display='block'" style="width:auto;">Login</button></li>
                    <li><a href='HOME.html'>Home page</a></li>
                    <li><a href='Application.html'>Application</a></li>
                    <li><a href='Employee.html'>Employee</a></li>
                    <li><a href='leave.html'>Leave</a></li>
                </ul>
            </nav>
        </div>
        <div id='login-form'class='login-page'>
            <div class="form-box">
                <div class='button-box'>
                    <div id='btn'></div>
                    <button type='button'onclick='login()'class='toggle-btn'>Log In</button>
                    <button type='button'onclick='register()'class='toggle-btn'>Register</button>
                </div>
                
                <form id='login' class='input-group-login' action="detail.php" method="post">
                    <label for="email">email</label>
                    <input type='text'class='input-field' required name="email">
                    <label for="Password">Password</label>
		    <input type='Password'class='input-field' required  name="Password">
		    <input type='checkbox'class='check-box'><span>Remember Password</span>
		    <button type='submit'class='submit-btn'>Log in</button>
		 </form>
		 <form id='register' class='input-group-register' action="register.php" method="post">
         <label for="FirstName">FirstName</label>
		     <input type='text'class='input-field' required name="FirstName">
             <label for="Last Name">LastName</label>
		     <input type='text'class='input-field' required name="LastName">
             <label for="EmailId">EmailId</label>
		     <input type='email'class='input-field' required name="EmailId">
             <label for="EnterPassword">Enterpassword</label>
		     <input type='password'class='input-field'required name="EnterPassword">
             <label for="ConfirmPassword"> ConfirmPassword</label>
		     <input type='password'class='input-field'required name="ConfirmPassword">
            
                    <button type='submit'class='submit-btn'>Register</button>
	         </form>
            </div>
        </div>
    </div>
    <script>
        var x=document.getElementById('login');
		var y=document.getElementById('register');
		var z=document.getElementById('btn');
		function register()
		{
			x.style.left='-400px';
			y.style.left='50px';
			z.style.left='110px';
		}
		function login()
		{
			x.style.left='50px';
			y.style.left='450px';
			z.style.left='0px';
		}
	</script>
	<script>
        var modal = document.getElementById('login-form');
        window.onclick = function(event) 
        {
            if (event.target == modal) 
            {
                modal.style.display = "none";
            }
        }
    </script>    
</body>
</html>