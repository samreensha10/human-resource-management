<?php
$email=$_POST['email'];
$Password=$_POST['Password'];
$servername="localhost";
$username="root";
$password="";
$dbname="hrms";
//Create connection
$conn=new mysqli($servername,$username,$password,$dbname);
// Check connection
if($conn->connect_error){
    die("connection failed:" . $conn->connect_error);


}
$sql="INSERT INTO login (email,password)
VALUES ('$email','$Password')";
if($conn->query($sql)==TRUE){
    echo"new record created sucessfully";
}
else{
   echo "error".$sql. "<br>" .$conn->error;


}
$conn->close();

?>